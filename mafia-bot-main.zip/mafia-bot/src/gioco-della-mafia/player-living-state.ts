export enum DeathCause {
  Lynched,
  Murdered,
  Banished,
  Modkilled,
}

export default interface PlayerLivingState {
  isAlive: boolean;
  cause?: DeathCause;
}

import { GuildMember } from "discord.js";
import Area from "./area.js";
import Rolecard from "./rolecard.js";
import Ability from "./ability.js";
import Balance from "./balance.js";
import PlayerLivingState from "./player-living-state.js";

export default class Player {
  member: GuildMember;
  area?: Area;
  areaTonight?: Area;
  abilities: Ability[] = [];
  rolecard: Rolecard;
  balance?: Balance;
  livingState: PlayerLivingState;

  constructor(member: GuildMember, rolecard: Rolecard) {
    this.member = member;
    this.rolecard = rolecard;
    this.livingState = { isAlive: true };
  }

  kill = async () => {};
}

import Residence from "./residence.js";
import Ability from "./ability.js";
import Faction from "./faction.js";

interface RolecardInterface {
  inGameName: string;
  inGameNameMeaning: string;
  roleName: string;
  roleNameMeaning: string;
  baseCapital: number;
  faction: Faction;
  imageURL: string;
  description: string;
  residence: Residence;
  abilities: {
    initial: Ability[];
    marketDay1: Ability[];
    marketDay2: Ability[];
  };
}

export default class Rolecard implements RolecardInterface {
  inGameName: string;
  inGameNameMeaning: string;
  roleName: string;
  roleNameMeaning: string;
  baseCapital: number;
  faction: Faction;
  imageURL: string;
  description: string;
  residence: Residence;
  abilities: {
    initial: Ability[];
    marketDay1: Ability[];
    marketDay2: Ability[];
  };

  constructor(rolecard: RolecardInterface) {
    this.inGameName = rolecard.inGameName;
    this.inGameNameMeaning = rolecard.inGameNameMeaning;
    this.roleName = rolecard.roleName;
    this.roleNameMeaning = rolecard.roleNameMeaning;
    this.baseCapital = rolecard.baseCapital;
    this.faction = rolecard.faction;
    this.imageURL = rolecard.imageURL;
    this.description = rolecard.description;
    this.residence = rolecard.residence;
    this.abilities = rolecard.abilities;
  }
}

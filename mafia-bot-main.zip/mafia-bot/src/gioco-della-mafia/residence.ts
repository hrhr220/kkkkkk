import Area from "./area.js";

type residenceName = "House A" | "House B" | "Block A" | "Block B";

export default interface Residence {
  area: Area;
  name: residenceName;
  rent: number;
  imageURL?: string;
}

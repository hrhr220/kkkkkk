import GiocoDellaMafia from "./gioco-della-mafia";

export { GiocoDellaMafia };

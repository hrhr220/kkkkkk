import Rolecard from "./rolecard";
import Ability from "./ability";

export default interface Faction {
  name: string;
  winConditionMessage: string;
  colour: string;
  abilities: Ability[];
  members: Rolecard[];
}

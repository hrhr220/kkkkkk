import { EventName } from "./event";
import Game from "./game";
import { Interactions } from "./interaction";
import { ListenerArguments, Listeners } from "./listener";

export const phaseNames = ["always", "before", "playing"] as const;
export type PhaseName = typeof phaseNames[number];

export interface PhaseInteractions {
  always: never;
  before: "signUp";
  playing: never;
}

export class Phase<Name extends PhaseName> {
  active = false;
  listeners: Listeners;
  interactions: Interactions<PhaseInteractions[Name]>;
  name: Name;

  constructor({
    name,
    listeners,
    interactions,
  }: {
    name: Name;
    listeners: Listeners;
    interactions: Interactions<PhaseInteractions[Name]>;
  }) {
    this.name = name;
    this.listeners = listeners;
    this.interactions = interactions;
  }

  async start() {}
  async end() {}
  async onStart() {}
  async onEnd() {}

  async activate<Name2 extends EventName>(
    eventName: Name2,
    game: Game,
    ...args: ListenerArguments[Name2]
  ) {
    this.listeners[eventName](game, ...args);

    for (const interaction of Object.values<{ [key: string]: any }>(
      this.interactions
    )) {
      interaction.activate(eventName, game, ...args);
    }
  }
}

export type Phases = { [key in PhaseName]: Phase<key> };

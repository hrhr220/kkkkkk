import { Snowflake, Message, Client } from "discord.js";

import Bot from "./bot";
import { CommandManager } from "./command";
import { EventManager } from "./event";
import { PhaseManager } from "./phase";
import { InteractionManager } from "./interaction";

export default class Game {
  bot: Bot;
  commands: CommandManager;
  events: EventManager;
  phases: PhaseManager;
  interactions: InteractionManager;
  prefix: string;

  constructor({
    token,
    serverId,
    events,
    phases,
    interactions,
    prefix,
  }: {
    token: string;
    serverId: Snowflake;
    events?: EventManager;
    phases?: PhaseManager;
    interactions?: InteractionManager;
    prefix?: string;
  }) {
    this.bot = this.initBot(token, serverId);
    this.commands = new CommandManager(this.bot, this);
    this.events = events || new EventManager({});
    this.phases = phases || new PhaseManager({});
    this.interactions = interactions || new InteractionManager({});
    this.prefix = prefix || "mb!";
  }

  private initBot = (token: string, serverId: Snowflake) => {
    const client = new Client({
      intents: [
        "GUILDS",
        "GUILD_MESSAGES",
        "GUILD_MESSAGE_REACTIONS",
        "GUILD_MEMBERS",
      ],
    });

    client.on("messageCreate", async (message: Message) => {
      this.events.activate("messageCreate", message);
    });

    client.on("messageReactionAdd", async () => {
      this.events.activate("messageReactionAdd");
    });

    client.on("messageReactionRemove", async () => {
      this.events.activate("messageReactionRemove");
    });

    client.on("interactionAdd", async () => {
      this.events.activate("interactionAdd");
    });

    // Initiate client
    client.login(token).catch((error) => {
      console.error("Could not login.");
      throw error;
    });

    return new Bot(client, serverId);
  };
}

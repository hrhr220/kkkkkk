import { Message } from "discord.js";
import CommandNamespace from "./command-namespace";
import CommandManager from "./command-manager";
import Game from "../game";

type Parameter = {
  name: string;
  description?: string;
  optional?: boolean;
  spread?: boolean;
  values?: string[];
};

type Option = {
  abbreviation?: string;
  description?: string;
};

export default class Command extends CommandNamespace {
  parameters?: Parameter[];
  options: { [key: string]: Option };

  constructor({
    id,
    isAdmin,
    shortDescription,
    description,
    subcommands,
    parameters,
    options = {},
  }: {
    id: string;
    isAdmin?: boolean;
    shortDescription?: string;
    description?: string;
    subcommands?: { [key: string]: Command };
    parameters?: Parameter[];
    options?: { [key: string]: Option };
  }) {
    super({ id, isAdmin, shortDescription, description, subcommands });
    this.parameters = parameters;
    this.options = options;
  }

  async execute({
    args,
    options,
    send,
    game,
    commands,
  }: {
    args: string[];
    options: { [key: string]: string | null };
    send: (message: string) => Promise<void>;
    game: Game;
    commands: CommandManager;
  }): Promise<string | undefined> {
    return;
  }

  minimumParameters() {
    if (!this.parameters) return 0;
    return this.parameters.filter((parameter) => !parameter.optional).length;
  }

  maximumParameters() {
    if (!this.parameters) return Infinity;
    if (this.parameters.length === 0) return 0;
    return this.parameters[this.parameters.length - 1].spread
      ? Infinity
      : this.parameters.length;
  }
}

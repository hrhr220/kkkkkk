import Command from "./command";

export default class CommandNamespace {
  id: string;
  isAdmin?: boolean;
  shortDescription?: string;
  description?: string;
  subcommands?: { [key: string]: Command };
  parent?: CommandNamespace;

  constructor({
    id,
    isAdmin,
    shortDescription,
    description,
    subcommands,
  }: {
    id: string;
    isAdmin?: boolean;
    shortDescription?: string;
    description?: string;
    subcommands?: { [key: string]: Command };
  }) {
    this.id = id;
    this.isAdmin = isAdmin;
    this.shortDescription = shortDescription;
    this.description = description;

    this.subcommands = subcommands;

    for (const id in subcommands) {
      const command = subcommands[id];
      command.parent = this;

      if (command.isAdmin === undefined) {
        command.isAdmin = this.isAdmin;
      }
    }
  }
}

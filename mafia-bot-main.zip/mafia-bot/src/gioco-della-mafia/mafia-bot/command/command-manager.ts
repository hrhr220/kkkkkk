import { Message } from "discord.js";
import Command from "./command";
import CommandNamespace from "./command-namespace";
import Bot from "../bot";
import Game from "../game";

export default class CommandManager {
  commands: { [key: string]: CommandNamespace };
  bot: Bot;
  game: Game;

  constructor(
    bot: Bot,
    game: Game,
    commands: { [key: string]: CommandNamespace } = {}
  ) {
    this.bot = bot;
    this.game = game;
    this.commands = commands;
  }

  private parseCommand(command: string) {
    const words: string[] = [];
    let inQuote = false;
    let quoteType = "";
    let backspace = false;
    let word = "";
    for (let i = 0; i < command.length; i++) {
      if (backspace) {
        if (command[i] === "n") {
          word += "\n";
        } else {
          word += command[i];
        }
        backspace = false;
      } else if (command[i] === "'" || command[i] === '"') {
        if (inQuote) {
          if (command[i] === quoteType) {
            inQuote = false;
          } else {
            word += command[i];
          }
        } else {
          inQuote = true;
          quoteType = command[i];
        }
      } else if (command[i] === " ") {
        if (word) words.push(word);
        word = "";
      } else if (command[i] === "\\") {
        backspace = true;
      } else {
        word += command[i];
      }
    }
    if (word) words.push(word);

    return words;
  }

  formatWarning({
    commandName,
    warning,
  }: {
    commandName?: string;
    warning: any;
  }) {
    return `:warning: **Warning** while running ${
      commandName ? "`" + commandName + "`" : ""
    }:\n${warning}`;
  }

  formatError({ commandName, error }: { commandName?: string; error: any }) {
    return `:x: **Error** while running ${
      commandName ? "`" + commandName + "`" : ""
    }:\n${error}`;
  }

  get(words: string[], withArgs?: false): CommandNamespace | undefined;
  get(
    words: string[],
    withArgs: true
  ): { command?: CommandNamespace; i: number; commandName: string };
  get(words: string[], withArgs?: boolean) {
    if (!(words[0] in this.commands))
      return withArgs ? { commandName: words[0], i: 0 } : undefined;

    let command = this.commands[words[0]];
    let commandName = words[0];

    let i = 1;
    while (withArgs ? command.subcommands : i < words.length) {
      commandName += ` ${words[i]}`;

      if (!command.subcommands || !(words[i] in command.subcommands))
        return withArgs ? { commandName, i } : undefined;

      command = command.subcommands[words[i]];
      i++;
    }

    return withArgs ? { command, i, commandName } : command;
  }

  getCommands(
    words?: string[]
  ): [{ [key: string]: CommandNamespace } | undefined, boolean] {
    if (words && words.length) {
      const command = this.get(words);
      return [command?.subcommands, command?.isAdmin || false];
    } else {
      return [this.commands, false];
    }
  }

  async execute({
    commandString,
    send,
    adminPrivileges,
  }: {
    commandString: string;
    send: (message: string) => Promise<void>;
    adminPrivileges: boolean;
  }): Promise<void>;
  async execute({
    words,
    send,
    adminPrivileges,
  }: {
    words: string[];
    send: (message: string) => Promise<void>;
    adminPrivileges: boolean;
  }): Promise<void>;
  async execute({
    commandString,
    words,
    send,
    adminPrivileges,
  }: {
    commandString: string;
    words: string[];
    send: (message: string) => Promise<void>;
    adminPrivileges: boolean;
  }): Promise<void> {
    if (!words) {
      words = this.parseCommand(commandString);
    }
    const options: { [key: string]: string | null } = {};

    const optionWords = words.filter((word) => word.startsWith("-"));

    words = words.filter((word) => !word.startsWith("-"));

    const { command, i, commandName } = this.get(words, true);

    if (!command) {
      return await send(
        this.formatError({
          commandName,
          error: `Command \`${commandName}\` not found.`,
        })
      );
    }

    if (!(command instanceof Command)) {
      return await send(
        this.formatError({
          commandName,
          error: `\`${commandName}\` is not a command on it's own: it requires a subcommand to be specified.`,
        })
      );
    }

    const args = words.slice(i);

    if (args.length < command.minimumParameters()) {
      return await send(
        this.formatError({
          commandName,
          error: `Too few parameters were passed.`,
        })
      );
    }
    if (args.length > command.maximumParameters()) {
      return await send(
        this.formatError({
          commandName,
          error: `Too many parameters were passed, but running anyway.`,
        })
      );
    }

    for (const word of optionWords) {
      if (word.startsWith("--")) {
        options[word.slice(2)] = null;
      } else if (word.startsWith("-")) {
        // Words that start with a single dash hold an option for each letter
        // e.g., -adl is the same as -a -d -l
        for (const abbreviatedOption of word.slice(1).split("")) {
          // Look for the option with the abbreviation we are looking for
          const [name] = Object.entries(command.options).find(
            ([name, option]) => (option.abbreviation = abbreviatedOption)
          ) || [abbreviatedOption];
          options[name] = null;
        }
      }
    }

    if (command.isAdmin && !adminPrivileges) {
      return await send(
        this.formatError({
          commandName,
          error: `You don't have the permissions to run this command!`,
        })
      );
    } else {
      try {
        const response = await command.execute({
          args,
          options,
          send,
          game: this.game,
          commands: this,
        });

        if (response && response.trim()) {
          await send(response);
        }
      } catch (error) {
        await send(this.formatError({ commandName, error }));
      }
    }
  }
}

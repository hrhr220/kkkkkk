import { EventName } from "./event";
import Game from "./game";
import { ListenerArguments, Listeners } from "./listener";

export class Interaction {
  listeners: Listeners;
  start: (game: Game) => Promise<void>;

  constructor({
    listeners,
    start,
  }: {
    listeners: Listeners;
    start: (game: Game) => Promise<void>;
  }) {
    this.listeners = listeners;
    this.start = start;
  }

  async activate<Name extends EventName>(
    eventName: Name,
    game: Game,
    ...args: ListenerArguments[Name]
  ): Promise<void> {
    this.listeners[eventName](game, ...args);
  }
}

export type Interactions<InteractionNames extends string> = {
  [key in InteractionNames]: Interaction;
};

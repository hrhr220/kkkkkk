import Game from "./game";
import { ListenerArguments } from "./listener";
import { Phases } from "./phase";

export type EventName = keyof ListenerArguments;

export class Event<Name extends EventName> {
  name: Name;
  phases: Phases;

  constructor(name: Name, phases: Phases) {
    this.name = name;
    this.phases = phases;
  }

  activate = async (game: Game, ...args: ListenerArguments[Name]) => {
    for (const phase of Object.values(this.phases)) {
      phase.activate(this.name, game, ...args);
    }
  };
}

export type Events = { [key in EventName]: Event<key> };

import dotenv from "dotenv";
import {
  Client,
  Guild,
  TextChannel,
  CategoryChannel,
  Snowflake,
} from "discord.js";
import { CategoryReference, TextChannelReference } from "../channel-references";

dotenv.config();

export default class Bot {
  client: Client;
  guild?: Guild;

  constructor(client: Client, serverId: Snowflake) {
    this.client = client;

    client.once("ready", async () => {
      const guild = await client.guilds.fetch(serverId);
      if (!guild) throw new Error("Guild not found.");
      this.guild = guild;
      await this.guild.channels.fetch();

      console.log("Ready!");
    });
  }

  async getCategory(
    channelOrReference: CategoryReference | CategoryChannel
  ): Promise<CategoryChannel> {
    if (channelOrReference instanceof CategoryChannel) {
      return channelOrReference;
    } else {
      if (!this.guild) throw new Error("No guild");

      const channels = await this.guild.channels.fetch();
      for (const [id, channel] of channels) {
        if (
          channel instanceof CategoryChannel &&
          channel.name === channelOrReference.name
        ) {
          return channel;
        }
      }
      throw new Error(`Category ${channelOrReference.name} not found`);
    }
  }

  async getTextChannel(
    channelOrReference: TextChannelReference | TextChannel
  ): Promise<TextChannel> {
    if (!this.guild) throw new Error("No guild");

    if (channelOrReference instanceof TextChannel) {
      return channelOrReference;
    } else {
      const category = await this.getCategory(channelOrReference.parent);

      for (const [, channel] of category.children) {
        if (
          channel instanceof TextChannel &&
          channelOrReference.name === channel.name
        ) {
          return channel;
        }
      }
      throw new Error(
        `Channel ${channelOrReference.parent.name}/${channelOrReference.name} not found`
      );
    }
  }

  async getChannel(
    channel:
      | CategoryChannel
      | CategoryReference
      | TextChannel
      | TextChannelReference
  ): Promise<CategoryChannel | TextChannel> {
    if (
      channel instanceof CategoryChannel ||
      channel instanceof CategoryReference
    ) {
      return this.getCategory(channel);
    } else {
      return this.getTextChannel(channel);
    }
  }

  async open(
    channel:
      | TextChannel
      | CategoryChannel
      | TextChannelReference
      | CategoryReference
  ) {
    channel = await this.getChannel(channel);
    await channel.permissionOverwrites.edit(channel.guild.roles.everyone, {
      SEND_MESSAGES: true,
    });
  }

  async close(
    channel:
      | TextChannel
      | CategoryChannel
      | TextChannelReference
      | CategoryReference
  ) {
    channel = await this.getChannel(channel);
    await channel.permissionOverwrites.edit(channel.guild.roles.everyone, {
      SEND_MESSAGES: false,
    });
  }
}

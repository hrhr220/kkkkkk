import { Message, MessageReaction } from "discord.js";
import { EventName } from "./event";
import Game from "./game";

export type ListenerArguments = {
  messageCreate: [Message];
  messageReactionAdd: [MessageReaction];
};

export type Listener<Name extends EventName> = (
  game: Game,
  ...args: ListenerArguments[Name]
) => Promise<void>;

export type Listeners = {
  [key in keyof ListenerArguments]: Listener<key>;
};

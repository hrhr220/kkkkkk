export class TextChannelReference {
  name: string;
  parent: CategoryReference;

  constructor(name: string, parent: CategoryReference) {
    this.name = name;
    this.parent = parent;
  }
}

export class CategoryReference {
  name: string;
  children: { [key: string]: TextChannelReference };

  constructor(name: string, children: { [key: string]: string }) {
    this.name = name;
    this.children = {};
    for (const id in children) {
      this.children[id] = new TextChannelReference(children[id], this);
    }
  }

  get(name: string): TextChannelReference {
    if (!(name in this.children))
      throw new Error(`Text channel \`${name}\` not found.`);
    return this.children[name];
  }
}

export class CategoryReferenceManager {
  categories: { [key: string]: CategoryReference };

  constructor(categories: { [key: string]: CategoryReference }) {
    this.categories = categories;
  }

  get(name: string): CategoryReference {
    if (!(name in this.categories))
      throw new Error(`Category \`${name}\` not found.`);
    return this.categories[name];
  }

  getChannel(categoryName: string, channelName: string) {
    return this.get(categoryName).get(channelName);
  }
}

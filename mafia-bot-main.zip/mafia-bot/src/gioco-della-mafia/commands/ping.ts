import { Command } from "../mafia-bot";

export default class Ping extends Command {
  constructor() {
    super({
      id: "ping",
      isAdmin: false,
      shortDescription: "Check the bot is working.",
      description:
        "Responds with 'Pong!' Use this command to check that the bot is working properly.",
      parameters: [],
    });
  }

  async execute() {
    return "Pong!";
  }
}

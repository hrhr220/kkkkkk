import { Command, Game } from "../../mafia-bot";

import HelpCommand from "./command";
import Commands from "./commands";

export default class Help extends Command {
  constructor() {
    super({
      id: "help",
      subcommands: {
        command: new HelpCommand(),
        commands: new Commands(),
      },
      shortDescription: "Gives some help.",
    });
  }

  async execute({ game }: { game: Game }) {
    return `Hi, I'm the Gioco della Mafia bot!
My prefix is \`${game.prefix}\`.
You can use the command \`${game.prefix}help commands\` to view a list of commands you can use.`;
  }
}

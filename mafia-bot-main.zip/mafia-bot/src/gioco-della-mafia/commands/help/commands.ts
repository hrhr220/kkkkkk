import { Command, CommandManager, Game } from "../../mafia-bot";

export default class Commands extends Command {
  constructor() {
    super({
      id: "commands",
      shortDescription: "Gets a list of bot commands.",
      parameters: [
        {
          name: "namespace",
          optional: true,
          spread: true,
          description:
            "The name of the namespace to get subcommands from. If none is provided, all main commands and namespaces are listed.",
        },
      ],
      options: {
        all: {
          abbreviation: "a",
          description: "List all commands including admin ones.",
        },
      },
    });
  }

  async execute({
    args,
    options,
    commands,
    game,
  }: {
    args: string[];
    options: { [key: string]: string | null };
    commands: CommandManager;
    game: Game;
  }) {
    let commandName = args.join(" ");
    let [commandsObject, isAdmin] = commands.getCommands(args);
    if (!commandsObject)
      throw new Error(`Commands for \`${commandName}\` not found.`);

    const all = "all" in options || isAdmin;

    let commandsString = "";

    for (const id in commandsObject) {
      const command = commandsObject[id];

      if (!command.isAdmin || all) {
        const commandEmojis = [];
        if (command instanceof Command) {
          commandEmojis.push(command.isAdmin ? ":wrench:" : ":hammer:");
        }
        if (command.subcommands) {
          commandEmojis.push(":toolbox:");
        }
        commandsString += `\n${commandEmojis.join(" ")} \`${id}\`: ${
          command.shortDescription || "No description provided."
        }`;
      }
    }

    const adminCommands: boolean = Object.entries(commandsObject).some(
      ([, command]) => command.isAdmin
    );

    return `**${
      commandName ? `Subcommands of \`${commandName}\`` : "Commands"
    }:**${commandsString}
${
  !all && adminCommands
    ? `\n**Note**: Admin commands have not been shown. To see them, add the \`--all\` option.`
    : ``
}
**Legend**: :hammer:: normal command, ${
      all ? ":wrench:: admin command, " : ""
    } :toolbox:: contains subcommands.
**Tip**: run \`${game.prefix}help command${
      commandName ? ` ${commandName}` : ""
    } <command>\` to get more information on a specific command.`;
  }
}

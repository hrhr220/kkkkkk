import { Command, CommandManager, Game } from "../../mafia-bot";

export default class HelpCommand extends Command {
  constructor() {
    super({
      id: "command",
      shortDescription: "Describes a command.",
      parameters: [
        {
          name: "command",
          spread: true,
          description: "The command to get a description on.",
        },
      ],
    });
  }

  async execute({
    args,
    game,
    commands,
  }: {
    args: string[];
    game: Game;
    commands: CommandManager;
  }) {
    const commandName = args.join(" ");
    const command = commands.get(args);
    if (!command) throw new Error(`The command ${commandName} was not found.`);

    let commandStructure = `${game.prefix}${commandName}`;

    let optionString = "\n";
    if (command instanceof Command && Object.entries(command.options).length) {
      commandStructure += " [OPTIONS]";
      optionString += "**Options:**";
      for (const id in command.options) {
        const option = command.options[id];
        optionString += `\n\`--${id}\`${
          option.abbreviation ? ", `-" + option.abbreviation + "`" : ""
        }: ${option.description || "No description provided."}`;
      }
    }

    let parameterString = "\n";

    if (command instanceof Command && command.parameters) {
      if (command.parameters.length) {
        parameterString += "**Parameters:**";
        for (const parameter of command.parameters) {
          if (parameter.optional) {
            commandStructure += ` [<${parameter.name}>]`;
          } else {
            commandStructure += ` <${parameter.name}>`;
          }

          if (parameter.spread) commandStructure += " ...";

          parameterString += `\n - \`<${parameter.name}>${
            parameter.spread ? "..." : ""
          }\`${parameter.optional ? " (optional)" : ""}: ${
            parameter.description || "No description provided."
          }`;
        }
      }
    } else if (command.subcommands) {
      commandStructure += ` ${
        command instanceof Command ? "[<command>]" : "<command>"
      } [<args>]`;
      parameterString += `Paramers:
 - \`<command>\`${
   command instanceof Command ? " *(optional)*" : ""
 }: The subcommand to run.
 - \`<args>\`: The arguments to pass to the subcommand. This depends on the subcommand you are executing.
Run \`${
        game.prefix
      }help commands ${commandName}\` to view the available subcommands for this command.`;
    } else {
      commandStructure += " ...";
      parameterString += "Parameter descriptions have not been provided.";
    }

    return `**Usage:**
\`\`\`
${commandStructure}
\`\`\`
${
  command.shortDescription
    ? "**Description:** " + command.shortDescription
    : "No description provided."
}${command.description ? "\n" + command.description : ""}
${parameterString}
${optionString}`;
  }
}

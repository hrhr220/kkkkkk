import { Message } from "discord.js";
import { Command, CommandManager } from "../mafia-bot";

export default class AsNotAdmin extends Command {
  constructor() {
    super({
      id: "as-not-admin",
      shortDescription:
        "Runs a command as a normal user (for testing purposes).",
      isAdmin: true,
      parameters: [
        {
          name: "command",
          spread: true,
          description: "The command to run.",
        },
      ],
    });
  }

  async execute({
    args,
    send,
    commands,
  }: {
    args: string[];
    send: (message: string) => Promise<void>;
    commands: CommandManager;
  }) {
    commands.execute({
      words: args,
      send,
      adminPrivileges: false,
    });
    return undefined;
  }
}

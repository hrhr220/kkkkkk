import { Command, Game } from "../mafia-bot";

export default class Phases extends Command {
  constructor() {
    super({
      id: "phases",
      shortDescription: "Gets a list of the game's phases.",
      isAdmin: true,
      parameters: [],
    });
  }

  async execute({ game }: { game: Game }) {
    let phaseString = "";

    for (const id in game.phases.phases) {
      const phase = game.phases.phases[id];

      phaseString += `\n - \`${id}\`: ${phase.active ? "active" : "inactive"}`;
    }

    return `Phases:${phaseString}`;
  }
}

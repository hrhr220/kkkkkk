import { Command } from "../mafia-bot";

export default class Echo extends Command {
  constructor() {
    super({
      id: "echo",
      isAdmin: false,
      shortDescription: "Echoes what you say.",
      parameters: [
        {
          name: "args",
          spread: true,
          optional: true,
          description: "What to say.",
        },
      ],
    });
  }

  async execute({ args }: { args: string[] }) {
    const echo = args.join(" ").trim();
    return echo || "Echo, echo, *echo*...";
  }
}

import { Bot, Game, CommandManager } from "../mafia-bot";

import AsNotAdmin from "./as-not-admin";
import Echo from "./echo";
import Help from "./help";
import Ping from "./ping";
import Phase from "./phase";
import Phases from "./phases";
import Prepare from "./prepare";

export default class GiocoCommandManager extends CommandManager {
  constructor(bot: Bot, game: Game) {
    super(bot, game, {
      "as-not-admin": new AsNotAdmin(),
      echo: new Echo(),
      help: new Help(),
      ping: new Ping(),
      phase: new Phase(),
      phases: new Phases(),
      prepare: new Prepare(),
    });
  }
}

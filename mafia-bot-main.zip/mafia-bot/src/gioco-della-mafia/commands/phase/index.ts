import { CommandNamespace } from "../../mafia-bot";

import End from "./end";
import Pause from "./pause";
import Resume from "./resume";
import Start from "./start";
import Status from "./status";

export default class Phase extends CommandNamespace {
  constructor() {
    super({
      id: "phase",
      isAdmin: true,
      shortDescription: "Commands for managing phases.",
      subcommands: {
        end: new End(),
        pause: new Pause(),
        resume: new Resume(),
        start: new Start(),
        status: new Status(),
      },
    });
  }
}

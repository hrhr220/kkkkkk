import { Command, Game } from "../../mafia-bot";

export default class Start extends Command {
  constructor() {
    super({
      id: "start",
      shortDescription: "Starts a phase.",
      parameters: [
        {
          name: "phase",
          description: "The name of the phase to start.",
        },
      ],
      options: {
        force: {
          abbreviation: "f",
          description: "Start the phase even if already active.",
        },
      },
    });
  }

  async execute({
    args,
    game,
    options,
  }: {
    args: string[];
    game: Game;
    options: { [key: string]: string | null };
  }): Promise<string> {
    const phase = game.phases.get(args[0]);
    if (phase.active && !("force" in options)) {
      return `Phase \`${args[0]}\` already started.`;
    }
    await phase.start();
    return `Phase \`${args[0]}\` started!`;
  }
}

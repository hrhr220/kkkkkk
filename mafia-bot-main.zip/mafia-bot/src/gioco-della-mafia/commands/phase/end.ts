import { Command, Game } from "../../mafia-bot";

export default class End extends Command {
  constructor() {
    super({
      id: "end",
      shortDescription: "Ends a phase.",
      parameters: [
        {
          name: "phase",
          description: "The name of the phase to end.",
        },
      ],
      options: {
        force: {
          abbreviation: "f",
          description: "End the phase even if already inactive.",
        },
      },
    });
  }

  async execute({
    args,
    game,
    options,
  }: {
    args: string[];
    game: Game;
    options: { [key: string]: string | null };
  }): Promise<string> {
    const phase = game.phases.get(args[0]);
    if (!phase.active && !("force" in options)) {
      return `Phase \`${args[0]}\` already ended.`;
    }
    await phase.end();
    return `Phase \`${args[0]}\` ended!`;
  }
}

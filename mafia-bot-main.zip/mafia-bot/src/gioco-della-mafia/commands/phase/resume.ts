import { Command, Game } from "../../mafia-bot";

export default class Resume extends Command {
  constructor() {
    super({
      id: "resume",
      shortDescription: "Resumes a phase.",
      parameters: [
        {
          name: "phase",
          description: "The name of the phase to resume.",
        },
      ],
    });
  }

  async execute({
    args,
    game,
  }: {
    args: string[];
    game: Game;
  }): Promise<string> {
    const phase = game.phases.get(args[0]);
    if (phase.active) {
      return `Phase \`${args[0]}\` already active.`;
    }
    phase.resume();
    return `Phase \`${args[0]}\` resumed!`;
  }
}

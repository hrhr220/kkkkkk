import { Command, Game } from "../../mafia-bot";

export default class Status extends Command {
  constructor() {
    super({
      id: "status",
      shortDescription: "Gets the status of a phase.",
      parameters: [
        {
          name: "phase",
          description: "The phase to get the status on",
        },
      ],
      options: {},
    });
  }

  async execute({ args, game }: { args: string[]; game: Game }) {
    const phase = game.phases.get(args[0]);
    return `Status of phase \`${args[0]}\`: **${
      phase.active ? "active" : "inactive"
    }**.`;
  }
}

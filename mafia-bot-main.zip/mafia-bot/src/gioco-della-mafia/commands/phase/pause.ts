import { Command, Game } from "../../mafia-bot";

export default class Pause extends Command {
  constructor() {
    super({
      id: "pause",
      shortDescription: "Pauses a phase.",
      parameters: [
        {
          name: "phase",
          description: "The name of the phase to pause.",
        },
      ],
    });
  }

  async execute({
    args,
    game,
  }: {
    args: string[];
    game: Game;
  }): Promise<string> {
    const phase = game.phases.get(args[0]);
    if (!phase.active) {
      return `Phase \`${args[0]}\` already paused.`;
    }
    phase.pause();
    return `Phase \`${args[0]}\` paused!`;
  }
}

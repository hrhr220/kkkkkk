import { Command, Game } from "../mafia-bot";

export default class Prepare extends Command {
  constructor() {
    super({
      id: "prepare",
      isAdmin: true,
      shortDescription: "Prepare the server for sign-ups.",
      description: "Alias for `phase start before`.",
      parameters: [],
    });
  }

  async execute({ game }: { game: Game }) {
    await game.phases.get("before").start();
    return "Finished preparing";
  }
}

import Player from "./player.js";
import Area from "./area.js";
import { DeathCause } from "./player-living-state.js";

export default interface Target {
  isValid: (player: Player) => boolean;
}

export class TargetInArea implements Target {
  area: Area;

  constructor(area: Area) {
    this.area = area;
  }

  isValid = (player: Player): boolean => {
    return player.area === this.area && player.livingState.isAlive;
  };
}

export class TargetIsLynched implements Target {
  isValid = (player: Player): boolean => {
    return (
      player.livingState.isAlive &&
      player.livingState.cause === DeathCause.Lynched
    );
  };
}

import { Phase } from "./mafia-bot";
import Target from "./targets";

export type Snarf = number | "N/A";
export type AbilityUses = number | "N/A" | "Unlimited";

export interface AbilityInterface {
  id: string;
  name: string;
  description?: string;
  imageURL?: string;
  phase: Phase;
  targets: Target[];
  cost: number;
  isActive: boolean;
  snarf: Snarf;
  uses: AbilityUses;
}

export default class Ability implements AbilityInterface {
  id: string;
  name: string;
  description?: string;
  imageURL?: string;
  phase: Phase;
  targets: Target[];
  cost: number;
  isActive: boolean;
  snarf: Snarf;
  uses: AbilityUses;

  constructor(ability: AbilityInterface) {
    this.id = ability.id;
    this.name = ability.name;
    this.description = ability.description;
    this.imageURL = ability.imageURL;
    this.phase = ability.phase;
    this.targets = ability.targets;
    this.cost = ability.cost;
    this.isActive = ability.isActive;
    this.snarf = ability.snarf;
    this.uses = ability.uses;
  }
}

import categoryReferences from "../channels";
import { Interaction } from "../mafia-bot";

export default class SignUp extends Interaction {
  start = async () => {
    const rulesChannel = await this.bot.getTextChannel(
      categoryReferences.getChannel("pregame", "rules")
    );
    const channel = await this.bot.getTextChannel(this.channel);

    const emoji = "✅";
    const message = await channel.send(
      `Once you've read the ${rulesChannel}, react with ${emoji} to sign up! If you just want to spectate, you don't have to do anything.`
    );
    await message.react(emoji);
  };
}

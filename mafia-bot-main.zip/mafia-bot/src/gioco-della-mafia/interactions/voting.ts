import { Interaction, Bot, TextChannelReference } from "../mafia-bot";

export default class Voting extends Interaction {
  options: string[];

  constructor(bot: Bot, channel: TextChannelReference, options: string[]) {
    super(bot, channel);
    this.options = options;
  }
}

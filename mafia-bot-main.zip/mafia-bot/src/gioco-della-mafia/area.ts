export default interface Area {
  name: string; // The name of the area
  parent?: Area; // The area this area is inside (optional)
  children: Area[]; // The areas that are inside this area
}

import { CommandManager, Event, EventManager } from "../mafia-bot";
import DiscordListenerManager from "../listeners/discord";

export default class GiocoEventManager extends EventManager {
  discordListeners: DiscordListenerManager;

  constructor({
    commands,
    prefix,
  }: {
    commands: CommandManager;
    prefix: string;
  }) {
    super({
      messageCreate: new Event(),
      messageReactionAdd: new Event(),
    });

    this.discordListeners = new DiscordListenerManager({
      events: this,
      commands,
      prefix,
    });

    this.discordListeners.subscribe();
  }
}

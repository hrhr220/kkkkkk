import { Snowflake } from "discord.js";
import { Game, InteractionManager } from "./mafia-bot";

import GiocoCommandManager from "./commands";
import GiocoPhaseManager from "./phases";
import GiocoEventManager from "./events";
import Player from "./player";

export default class GiocoDellaMafia extends Game {
  players: Player[] = [];

  constructor({
    token,
    serverId,
    prefix,
  }: {
    token: string;
    serverId: Snowflake;
    prefix?: string;
  }) {
    super({ token, serverId, prefix: prefix || "g!" });

    this.commands = new GiocoCommandManager(this.bot, this);

    this.events = new GiocoEventManager({
      commands: this.commands,
      prefix: this.prefix,
    });

    this.phases = new GiocoPhaseManager({ events: this.events, bot: this.bot });
    this.interactions = new InteractionManager();
  }
}

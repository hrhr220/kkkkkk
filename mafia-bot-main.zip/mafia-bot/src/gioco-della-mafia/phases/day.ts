import { Bot, EventManager, Phase } from "../mafia-bot";

export default class Day extends Phase {
  constructor({ events, bot }: { events: EventManager; bot: Bot }) {
    super({ id: "day", listeners: {}, events, bot });
  }

  onStart = async () => {};
}

import { MessageReaction } from "discord.js";
import { Game, Listener } from "../../mafia-bot";

const messageReactionAdd: Listener<"messageReactionAdd"> = async (
  game: Game,
  reaction: MessageReaction
) => {};

export default messageReactionAdd;

import { Interaction, Interactions, Phase } from "../../mafia-bot";
import messageCreate from "./message-create";
import messageReactionAdd from "./message-reaction-add";

const always = new Phase({
  name: "always",
  listeners: {
    messageCreate,
    messageReactionAdd,
  },
  interactions: {},
});

export default always;

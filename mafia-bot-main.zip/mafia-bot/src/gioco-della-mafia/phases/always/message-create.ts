import { Message } from "discord.js";
import { Game, Listener } from "../../mafia-bot";

const messageCreate: Listener<"messageCreate"> = async (
  game: Game,
  message: Message
) => {
  if (!message.member?.user.bot && message.content.startsWith(game.prefix)) {
    const isAdmin = message.member?.permissions.has("ADMINISTRATOR") || false;

    await game.commands.execute({
      commandString: message.content.substring(game.prefix.length),
      send: async (msg: string) => {
        await message.channel.send(msg);
      },
      adminPrivileges: isAdmin,
    });
  }
};

export default messageCreate;

import { Bot, EventManager, Phase } from "../mafia-bot";

export default class ChessGame extends Phase {
  constructor({ events, bot }: { events: EventManager; bot: Bot }) {
    super({ id: "chess-game", listeners: {}, events, bot });
  }

  onStart = async () => {};
}

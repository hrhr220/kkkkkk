import { Bot, EventManager, PhaseManager } from "../mafia-bot";
import Before from "./before";
import Betting from "./betting";
import Candidate from "./candidate";
import ChessGame from "./chess-game";
import Day from "./day";
import Night from "./night";
import Playing from "./playing";

export default class GiocoPhaseManager extends PhaseManager {
  constructor({ events, bot }: { events: EventManager; bot: Bot }) {
    super({
      before: new Before({ events, bot }),
      betting: new Betting({ events, bot }),
      candidate: new Candidate({ events, bot }),
      "chess-game": new ChessGame({ events, bot }),
      day: new Day({ events, bot }),
      night: new Night({ events, bot }),
      playing: new Playing({ events, bot }),
    });
  }
}

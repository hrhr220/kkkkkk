import { Bot, EventManager, Phase } from "../mafia-bot";

export default class Betting extends Phase {
  constructor({ events, bot }: { events: EventManager; bot: Bot }) {
    super({ id: "betting", listeners: {}, events, bot });
  }

  onStart = async () => {};
}

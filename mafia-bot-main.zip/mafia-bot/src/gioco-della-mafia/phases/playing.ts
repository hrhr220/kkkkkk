import { Bot, EventManager, Phase } from "../mafia-bot";

export default class Playing extends Phase {
  constructor({ events, bot }: { events: EventManager; bot: Bot }) {
    super({ id: "playing", listeners: {}, events, bot });
  }

  onStart = async () => {};
}

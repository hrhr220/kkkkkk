import categoryReferences from "../channels";
import { Bot, EventManager, InteractionManager, Phase } from "../mafia-bot";
import SignUp from "../interactions/sign-up";

export default class Before extends Phase {
  constructor({ events, bot }: { events: EventManager; bot: Bot }) {
    super({
      id: "before",
      listeners: {},
      interactions: new InteractionManager({
        "sign-up": new SignUp(
          bot,
          categoryReferences.getChannel("pregame", "signUp")
        ),
      }),
      events,
      bot,
    });
  }

  onStart = async () => {
    await this.bot.open(categoryReferences.getChannel("pregame", "hangout"));

    const dmCategory = await this.bot.getCategory(
      categoryReferences.get("playerDms")
    );
    for (const [, channel] of dmCategory.children) {
      await channel.delete();
    }

    await this.bot.close(categoryReferences.get("game"));
    await this.bot.close(categoryReferences.get("ndranghetaCalabria"));
    await this.bot.close(categoryReferences.get("camorra"));
    await this.bot.close(categoryReferences.get("footballFaction"));

    const signUpChannel = await this.bot.getTextChannel(
      categoryReferences.getChannel("pregame", "signUp")
    );
    await signUpChannel.delete();
    const pregame = await this.bot.getCategory(
      categoryReferences.get("pregame")
    );
    pregame.createChannel("sign-up");

    await this.interactions?.get("sign-up")?.start();

    // TODO: Close factional categories
  };
}

import { Bot, EventManager, Phase } from "../mafia-bot";

export default class Night extends Phase {
  constructor({ events, bot }: { events: EventManager; bot: Bot }) {
    super({ id: "night", listeners: {}, events, bot });
  }

  onStart = async () => {};
}

export default class Balance {
  private _money: number;
  public onNegativeBalance: () => void;

  constructor(money = 0, onNegativeBalance: () => void) {
    this._money = money;
    this.onNegativeBalance = onNegativeBalance;
  }

  public get balance() {
    return this._money;
  }

  public set balance(money: number) {
    this._money = money;

    if (money < 0) {
      this.onNegativeBalance();
    }
  }
}

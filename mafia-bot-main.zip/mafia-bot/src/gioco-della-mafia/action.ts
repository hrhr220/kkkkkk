export interface ActionStep {
  params: any[];
  doAction: (...args: any[]) => string;
}

type Action = ActionStep | Action[];

export default Action;

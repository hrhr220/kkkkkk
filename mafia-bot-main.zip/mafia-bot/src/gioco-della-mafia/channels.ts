import { CategoryReferenceManager, CategoryReference } from "./mafia-bot";

const pregame = new CategoryReference("Pregame", {
  welcome: "welcome",
  signUp: "sign-up",
  announcements: "announcements",
  hangout: "pregame-hangout",
  rules: "rules",
  memes: "memes",
});

const game = new CategoryReference("The Game!", {
  players: "players",
  voting: "voting",
  betting: "betting",
});

const alleys = new CategoryReference("Alley Chat", {
  gamblersDen: "gamblers-den",
  townSquare: "town-square",
  southernFields: "southern-fields",
  market: "market",
});

const ndrangheta = new CategoryReference("N'Drangheta + Calabria", {
  notes: "notes",
  chat: "factional-chat",
});

const camorra = new CategoryReference("Camorra", {
  notes: "notes",
  chat: "factional-chat",
});

const footballFaction = new CategoryReference("Football Faction", {
  notes: "notes",
  chat: "factional-chat",
});

const playerDms = new CategoryReference("Player DM's", {
  notes: "notes",
  chat: "factional-chat",
});

export default new CategoryReferenceManager({
  pregame,
  game,
  alleys,
  ndrangheta,
  calabria: ndrangheta,
  ndranghetaCalabria: ndrangheta,
  camorra,
  footballFaction,
  playerDms,
});

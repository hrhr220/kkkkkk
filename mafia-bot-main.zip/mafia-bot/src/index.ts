import { GiocoDellaMafia } from "./gioco-della-mafia";

if (!process.env.TOKEN) throw new Error("Token is not set!");
if (!process.env.SERVER_ID) throw new Error("Server ID is not set!");

new GiocoDellaMafia({
  token: process.env.TOKEN,
  serverId: process.env.SERVER_ID,
});
